<div class="footer">
            <h2>Viam supervadet vadens «Дорогу осилит идущий».</h2>
        </div>