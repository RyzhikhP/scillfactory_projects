

<?php 
 $p = 'Приветствую Вас на моей страничке! ';
?>

<?php 
 $name = 'Павел';
 $surname = 'Рыжих';
 $city = 'Уссурийск';
 $age = 43;
?>


<?php
include 'main.php';
?>

