            <nav>
                <ul>
                    <li><a href="index.php"> Главная </a></li>
                    <li><a href="ver_php.inc.php"> О версии PHP </a></li>
                    <li><a href="knowledge.inc.php"> Примеры PHP </a></li>
                </ul>    
            </nav>