    
                <div class="logo"> 
                <img src="img/logo_bug.png" alt="php">
                </div>                                                 
        