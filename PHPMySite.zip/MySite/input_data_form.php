<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Данные в POST </title>
    <link rel="stylesheet" href="style.css" /> 
</head>
<body>
<div class="flex-container">

        <div class="header">     
               <?php include 'logo.inc.php' ?>         
               <?php include 'menu.inc.php' ?>	   
        </div> 
        <div class="form"> 
                введенное значение: 
                <?php echo $_POST["val_form"]; 
                $val_form=(int)$_POST["val_form"];
                if ($val_form) {
                session_start(); $val = $val_form; $_SESSION['val'] = $val; // передача значения переменной $val в "knowledge.inc.php
                echo '<br>';
                echo '<a href="knowledge.inc.php" "> - Возврат на предыдущую страницу</a>';
                } else {
                    echo '<br>';
                    echo ('вы не ввели число');
                    echo '<a href="knowledge.inc.php" "> - Возврат на предыдущую страницу</a>';
                }
                ?>
        </div>
</div>
</body>
</html>



