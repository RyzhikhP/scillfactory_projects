<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Практика PHP </title>
    <link rel="stylesheet" href="style.css" /> 
</head>
<body>
    <div class="flex-container">

        <div class="header">     
               <?php include 'logo.inc.php' ?>         
               <?php include 'menu.inc.php' ?>	   
        </div> 

        <H2>Пример 1: Присвоение значений переменным</H2>      
        <div class="knowledge">
              <?php           
                $a = 'Выполнил задание на';
                $b = 100;
                $c = '%'; 
              ?>
              <?php   echo $a, ' ', $b, ' ', $c; ?> <br><br>  
        </div>
        
        <H2>Пример 2: Сложение целочисленных переменных</H2>
        <div class="knowledge">           
              <?php
                $a = 410;
                $b = 240;
                $c = $a + $b;
                echo 'a='.$a.'<br>';
                echo 'b='.$b.'<br>';            
                echo 'Сумма двух переменных ($a+$b=$c) c='.$c.'<br>';
              ?> <br><br>                
        </div>

        <H2>Пример 3: Работа с передачей данных использовал POST и передачу через сессию ($_SESSION)</H2>    
        <div class="knowledge">
                <form action="input_data_form.php" method="post">
                  Ввведите число: <input type="text" name="val_form"><br>
                  <input type="submit">
                </form>        
        </div>   
        
        <div class="knowledge">
                <?php
                  session_start(); // получение данных из формы
                  echo 'Введенное число=';
                  echo $_SESSION['val']; 
                  $val=  $_SESSION['val'];
                ?>
        </div>

        <H2>Пример 4: Операции сравнения. Сравним полученное введенное выше число со значением 1500 </H2> 
        <div class="knowledge">               
                <?php
                  $val2=1500;
                  if($val > $val2) {
                    echo 'введенное число больше 1500 '.'<br>';
                  } elseif ($val == $val2) {
                    echo 'введенное число равно 1500 '.'<br>';
                  }else{
                    echo 'введенное число меньше 1500 '.'<br>';
                  }
                ?>  
        </div>

        <H2>Пример 6: Использование циклов FOR, While. Замер скорости переборки этими циклами </H2>
        <div class="knowledge">                                                                                                      
                  <?php
                    //считает длительность выполнения переборки циклом FOR с помощью microtime()                              
                    echo 'Переберем и выведем на экран значения от 1 до 50 в цикле FOR'.'<br>' ;
                    $start = microtime(true); // замер времени испполнения скрипта
                    for($i = 1; $i < 51; $i++) {
                      echo $i; 
                      echo '--';
                    }
                    $time_for=microtime(true) - $start;                        
                    echo '<br>';
                    echo 'Время переборки от 1 до 50 циклом FOR составляет: ' . $time_for . ' sec.'.'<br>';
                    echo '<br>';
                  ?>                              
                                          
                  <?php
                    //считает длительность выполнения переборки циклом while   
                    echo 'Переберем и выведем на экран значения от 1 до 50 в цикле WHILE'.'<br>' ;
                    $start = microtime(true); // замер времени испполнения скрипта                          
                    $i = 1;
                    while ($i <= 50) {
                      echo $i++;
                      echo '--';
                    }
                    $time_while=microtime(true) - $start;
                    echo '<br>';
                    echo 'Время переборки от 1 до 50 циклом while составляет: ' . $time_while . ' sec.'.'<br>';            
                 ?>
        </div>
        <?php include 'footer.inc.php' ?>   
    </div>
</body>

<html>

